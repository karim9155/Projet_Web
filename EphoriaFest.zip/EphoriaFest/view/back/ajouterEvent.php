<?php
include '../controller/EventController.php';

$event=new EventController();
if(
    isset($_POST['id_event']) && !empty($_POST['id_event'])
    && isset($_POST['nom_event']) && !empty($_POST['nom_event'])
    && isset($_POST['theme_event']) && !empty($_POST['theme_event'])
    && isset($_POST['artiste_event']) && !empty($_POST['artiste_event'])
    && isset($_POST['prix_event']) && !empty($_POST['prix_event'])
   
){
    $event = new Event($_POST['id_event'],$_POST['nom_event'],$_POST['theme_event'],$_POST['artiste_event'],$_POST['prix_event']);
    $events->ajouterEvent($event);
}
else
echo 'veuillez verifier vos données';
header('Location: evenement.php');
?>