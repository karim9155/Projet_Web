<?php
include "/xampp/htdocs/EphoriaFest/model/Event.php";

class EventController
{
    public function ajouterEvent($event)
    {
        $db = config::getConnexion();
        $req = "INSERT INTO `evenement`(`id_event`, `nom_event`,`theme_event`, `artiste_event`, `prix_event`) VALUES (:id_event,:nom_event,:theme_event,:atiste_event,:prix_event)";
        $sql = $db->prepare($req);
        $sql->bindValue(':id_event', $event->getId_event());
        $sql->bindValue(':nom_event', $event->getNom_event());
        $sql->bindValue(':theme_event', $event->getTheme_event());
        $sql->bindValue(':atiste_event', $event->getArtiste_event());
        $sql->bindValue(':prix_event', $event->getPrix_event());

        if ($sql->execute()) {
            $last_id = $db->lastInsertId();
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=forum-detail.php?id=" . $last_id . "\">";
        } else
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=ajouter-event.php\">";
    }
    

    public function afficherEvent()
    {
        $db = config::getConnexion();
        $result = "SELECT * FROM evenement";
        $sql = $db->query($result);
        return $sql;
    }

    public function supprimerEvent($id)
    {
        $db = config::getConnexion();
        $sql = $db->prepare("DELETE FROM event WHERE id= $id");
        if ($sql->execute())
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=forum.php\">";
        else
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=forum.php\">";
    }

    public function modifierEvent($event, $id_event)
    {
        $db = config::getConnexion();
        $req = "UPDATE `event` SET `titre`=:titre,`categorie`=:categorie,`event`=:event,`date_event`=now() WHERE id=$id_event";
        $sql = $db->prepare($req);
        $sql->bindValue(':titre', $event->get_titre());
        $sql->bindValue(':categorie', $event->get_categorie());
        $sql->bindValue(':event', $event->get_event());
        if ($sql->execute())
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=forum-detail.php?id=" . $id_event . "\">";
        else
            echo "<meta http-equiv=\"refresh\" content=\"0;URL=forum-detail.php?id=" . $id_event . "\">";
    }
}
