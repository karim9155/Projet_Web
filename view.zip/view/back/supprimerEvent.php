<?php
include_once '../../controller/EventController.php';
$events=new EventController();
$events->supprimerEvent($_GET["id_event"]);
header('Location: afficherListeEvent.php');
?>